# CRT CSS effect for Web
![CSS3](https://img.shields.io/badge/css3-000000.svg?style=for-the-badge&logo=css3&logoColor=white)
![HTML5](https://img.shields.io/badge/html5-000000.svg?style=for-the-badge&logo=html5&logoColor=white)

## Introduction
[LIVE PREVIEW](https://codesandbox.io/s/github/D3nn7/crt-css)

This repository has a simple CRT (TV) effect in CSS.

Thanks to [Patrick H. Lauke](https://codepen.io/patrickhlauke/pen/YaoBop) for his Codepen example.


## License?
I love Open Source and decide that this small project don't need a license. You can use it without any restrictions.

## Fonts
In this repository I used [Noto Sans Display](https://fonts.google.com/noto/specimen/Noto+Sans+Display).